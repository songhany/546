const searchData = require('./search');
const showData = require('./shows');

module.exports = {
  search: searchData,
  shows: showData,
};

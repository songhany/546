const showData = require('./shows');
const aboutmeData = require('./aboutme');

module.exports = {
    shows: showData,
    aboutme: aboutmeData,
};